const express = require('express');
const app = express();
const PORT = 3000;

// Настройки
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

// Временное хранилище (вместо БД)
let letters = [];
let nextId = 1;

// Навигация (для всех страниц)
app.use((req, res, next) => {
    res.locals.navLinks = [
        { href: '/', text: '🏠 Главная' },
        { href: '/letter', text: '📝 Написать письмо' },
        { href: '/about', text: 'ℹ️ О проекте' }
    ];
    next();
});

// Главная страница
app.get('/', (req, res) => {
    res.render('index', {
        title: 'Письмо Деду Морозу',
        lettersCount: letters.length
    });
});

// Страница формы
app.get('/letter', (req, res) => {
    res.render('form', {
        title: 'Написать письмо',
        error: null,
        old: {}
    });
});

// Обработка формы
app.post('/letter', (req, res) => {
    const { name, age, wish } = req.body;

    // Валидация
    let error = null;
    if (!name || name.trim() === '') {
        error = 'Имя обязательно для заполнения';
    } else if (!age || isNaN(age) || age < 3 || age > 12) {
        error = 'Возраст должен быть числом от 3 до 12 лет';
    } else if (!wish || wish.trim() === '') {
        error = 'Пожалуйста, напишите своё желание';
    } else if (wish.trim().length > 200) {
        error = 'Желание должно быть не длиннее 200 символов';
    }

    if (error) {
        return res.render('form', {
            title: 'Написать письмо',
            error,
            old: req.body
        });
    }

    // Сохранение письма
    const newLetter = {
        id: nextId++,
        name: name.trim(),
        age: parseInt(age),
        wish: wish.trim(),
        date: new Date().toLocaleDateString('ru-RU', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })
    };
    letters.push(newLetter);

    // Перенаправление на страницу результата
    res.redirect(`/result/${newLetter.id}`);
});

// Страница результата
app.get('/result/:id', (req, res) => {
    const letter = letters.find(l => l.id == req.params.id);
    if (!letter) {
        // Если письмо не найдено, перенаправляем на главную
        return res.redirect('/');
    }
    res.render('result', {
        title: 'Ваше письмо готово!',
        letter
    });
});

// О проекте
app.get('/about', (req, res) => {
    res.render('about', {
        title: 'О проекте',
        phone: '+7 (123) 456-78-90',
        address: 'ул. Пушкина, д. Колотушкина, Великий Устюг',
        email: 'santa@northpole.ru'
    });
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен: http://localhost:${PORT}`);
    console.log(`Писем в базе: ${letters.length}`);
});